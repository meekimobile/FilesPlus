<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ru">
<context>
    <name>AuthPage</name>
    <message>
        <location filename="../qml/FilesPlus/meego/AuthPage.qml" line="+127"/>
        <location filename="../qml/FilesPlus/symbian/AuthPage.qml" line="+128"/>
        <source>^API Request Authorized</source>
        <translation>утверженный запрос ^API</translation>
    </message>
</context>
<context>
    <name>ChartMenu</name>
    <message>
        <location filename="../qml/FilesPlus/meego/ChartMenu.qml" line="+15"/>
        <source>Settings</source>
        <translation>Установки</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>About</source>
        <translation type="unfinished">О приложении</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Exit</source>
        <translation>Выход</translation>
    </message>
</context>
<context>
    <name>CloudDriveAccountsPage</name>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveAccountsPage.qml" line="+75"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveAccountsPage.qml" line="+78"/>
        <source>Cloud Drive Accounts</source>
        <translation>Учет привода облака</translation>
    </message>
    <message>
        <location line="+38"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveAccountsPage.qml" line="+38"/>
        <source>Remove cloud drive account</source>
        <translation>Извлекайте учет привода облака</translation>
    </message>
    <message>
        <location line="+6"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveAccountsPage.qml" line="+6"/>
        <source>Please confirm to remove </source>
        <translation>Пожалуйста подтвердите для того чтобы извлечь</translation>
    </message>
</context>
<context>
    <name>CloudDriveJobsPage</name>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveJobsPage.qml" line="+79"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveJobsPage.qml" line="+82"/>
        <source>Cloud Drive Jobs</source>
        <translation>Работы привода облака</translation>
    </message>
    <message>
        <location line="+80"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveJobsPage.qml" line="+79"/>
        <source>Running</source>
        <translation>Работать</translation>
    </message>
    <message>
        <location line="+0"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveJobsPage.qml" line="+0"/>
        <source>Queued</source>
        <translation>Очередь</translation>
    </message>
</context>
<context>
    <name>CloudDriveUsersDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveUsersDialog.qml" line="+26"/>
        <location line="+8"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="+26"/>
        <location line="+8"/>
        <source>Sync</source>
        <translation>Синхронизируйте</translation>
    </message>
    <message>
        <location line="-8"/>
        <location line="+8"/>
        <location line="+4"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="-8"/>
        <location line="+8"/>
        <location line="+4"/>
        <source>to</source>
        <translation>к</translation>
    </message>
    <message>
        <location line="-4"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="-4"/>
        <source>items</source>
        <translation>детали</translation>
    </message>
    <message>
        <location line="+0"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="+0"/>
        <source>item</source>
        <translation>деталь</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="+4"/>
        <source>Upload</source>
        <translation>Upload</translation>
    </message>
    <message>
        <location line="+3"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="+3"/>
        <source>Download</source>
        <translation>Загрузка</translation>
    </message>
    <message>
        <location line="+0"/>
        <location line="+3"/>
        <location line="+3"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="+0"/>
        <location line="+3"/>
        <location line="+3"/>
        <source>from</source>
        <translation>от</translation>
    </message>
    <message>
        <location line="-3"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="-3"/>
        <source>Share link of</source>
        <translation>Соединение доли</translation>
    </message>
    <message>
        <location line="+3"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="+3"/>
        <source>Unsync</source>
        <translation>разъединение</translation>
    </message>
</context>
<context>
    <name>CommonDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/CommonDialog.qml" line="+16"/>
        <source>OK</source>
        <translation>Да</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Cancel</source>
        <translation>Нет</translation>
    </message>
</context>
<context>
    <name>ConfirmDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/ConfirmDialog.qml" line="+8"/>
        <location filename="../qml/FilesPlus/symbian/ConfirmDialog.qml" line="+11"/>
        <source>OK</source>
        <translation>Да</translation>
    </message>
    <message>
        <location line="+0"/>
        <location filename="../qml/FilesPlus/symbian/ConfirmDialog.qml" line="+0"/>
        <source>Cancel</source>
        <translation>Нет</translation>
    </message>
</context>
<context>
    <name>DownloadProgressDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/DownloadProgressDialog.qml" line="+16"/>
        <location filename="../qml/FilesPlus/symbian/DownloadProgressDialog.qml" line="+16"/>
        <source>Downloading</source>
        <translation>Загружать</translation>
    </message>
    <message>
        <location line="+2"/>
        <location filename="../qml/FilesPlus/symbian/DownloadProgressDialog.qml" line="+2"/>
        <source>OK</source>
        <translation>Да</translation>
    </message>
</context>
<context>
    <name>DriveGrid</name>
    <message>
        <location filename="../qml/FilesPlus/meego/DriveGrid.qml" line="+146"/>
        <location filename="../qml/FilesPlus/symbian/DriveGrid.qml" line="+146"/>
        <source>Free</source>
        <translation>Загружать</translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="../qml/FilesPlus/symbian/DriveGrid.qml" line="+1"/>
        <source>Total</source>
        <translation>Итог</translation>
    </message>
</context>
<context>
    <name>DriveMenu</name>
    <message>
        <location filename="../qml/FilesPlus/meego/DriveMenu.qml" line="+15"/>
        <source>Settings</source>
        <translation>Установки</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>About</source>
        <translation>О</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Exit</source>
        <translation>Выход</translation>
    </message>
</context>
<context>
    <name>DrivePage</name>
    <message>
        <location filename="../qml/FilesPlus/meego/DrivePage.qml" line="+101"/>
        <location filename="../qml/FilesPlus/symbian/DrivePage.qml" line="+105"/>
        <source>Drives</source>
        <translation>Хранения</translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/symbian/DrivePage.qml" line="-61"/>
        <source>About</source>
        <translation>О</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>More Apps</source>
        <translation>Больше Apps</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Settings</source>
        <translation>Установки</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Exit</source>
        <translation>Выход</translation>
    </message>
</context>
<context>
    <name>FilesPlusInfo</name>
    <message>
        <location filename="../qml/FilesPlus/meego/FilesPlusInfo.qml" line="+41"/>
        <location filename="../qml/FilesPlus/symbian/FilesPlusInfo.qml" line="+41"/>
        <source>FilesPlus provides extended functions beyond file manager.
   + Print with Google Cloud Print.
   + Sync with Cloud Drive.
   + Preview images in your folder.
   + Present folders in Pie view.</source>
        <translation>FilesPlus обеспечивает выдвинутые функции за файловым менеджером.
   + Печать с печатью облака Google.
   + Синхронизация с приводом облака.
   + Изображения предваротельного просмотра в вашем скоросшивателе.
   + Присутствующие скоросшиватели в взгляде расстегая.</translation>
    </message>
    <message>
        <location line="+41"/>
        <location filename="../qml/FilesPlus/symbian/FilesPlusInfo.qml" line="+41"/>
        <source>Developed by </source>
        <translation>Превращено мимо</translation>
    </message>
</context>
<context>
    <name>FolderPage</name>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="+23"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+23"/>
        <source>Paste</source>
        <translation>Затир</translation>
    </message>
    <message>
        <location line="+0"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+0"/>
        <source>Mark multiple items</source>
        <translation>Маркируйте множественные детали</translation>
    </message>
    <message>
        <location line="+0"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+0"/>
        <source>Clear clipboard</source>
        <translation>Ясная доска сзажимом для бумаги</translation>
    </message>
    <message>
        <location line="+0"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+0"/>
        <source>New folder</source>
        <translation>Новый скоросшиватель</translation>
    </message>
    <message>
        <location line="+0"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+0"/>
        <source>Sync current folder</source>
        <translation>Скоросшиватель течения синхронизации</translation>
    </message>
    <message>
        <location line="+0"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+0"/>
        <source>Sort by</source>
        <translation>Вид мимо</translation>
    </message>
    <message>
        <location line="+155"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+135"/>
        <source>Reset folder cache</source>
        <translation>Переустановите тайник скоросшивателя</translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+1"/>
        <source>Resetting folder cache will take time depends on numbers of sub folders/files under current folder.

Please click OK to continue.</source>
        <translation>Переустановить тайник скоросшивателя примет номера быть в зависимости от времени скоросшивателей/архивов под настоящий скоросшиватель.

Пожалуйста щелкните да для того чтобы продолжать.</translation>
    </message>
    <message>
        <location line="+35"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+35"/>
        <source>Notify</source>
        <translation>Сообщите</translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+1"/>
        <source>Reset Cache is running. Please wait until it&apos;s done.</source>
        <translation>Тайник возврата работает. Пожалуйста ждите до тех пор пока он не будет делать.</translation>
    </message>
    <message>
        <location line="+17"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+17"/>
        <source>Print Error</source>
        <translation>Ошибка печати</translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+1"/>
        <source>Can&apos;t print</source>
        <translation>Не смогите напечатать</translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+1"/>
        <source>File type is not supported. Only JPEG, PNG, Text and PDF are supported.</source>
        <translation>Тип архива не поддержан. Только поддержаны JPEG, PNG, текст и PDF.</translation>
    </message>
    <message>
        <location line="+6"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+6"/>
        <source>FilesPlus print via Google CloudPrint service.
Please enable printer on your desktop with Chrome or with CloudPrint-ready printer.
You will redirect to authorization page.</source>
        <translation>Печать FilesPlus через обслуживание Google CloudPrint.
Пожалуйста включите принтер на вашем настольном компьютере с кромом или с CloudPrint-готовым принтером.
Вы перенаправите к странице утверждения.</translation>
    </message>
    <message>
        <location line="+3"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+3"/>
        <source>Print with CloudPrint</source>
        <translation>Печать с CloudPrint</translation>
    </message>
    <message>
        <location line="+13"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+13"/>
        <source>Search for printers</source>
        <translation>Поиск для принтеров</translation>
    </message>
    <message>
        <location line="+32"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+32"/>
        <source>FilesPlus syncs your files via Dropbox service.
You will be redirected to authorization page.</source>
        <translation>FilesPlus синхронизирует ваши архивы через обслуживание Dropbox.
Вы будете перенаправлены к странице утверждения.</translation>
    </message>
    <message>
        <location line="+2"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+2"/>
        <source>Sync with Dropbox</source>
        <translation>Синхронизация с Dropbox</translation>
    </message>
    <message>
        <location line="+107"/>
        <location line="+773"/>
        <location line="+30"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+107"/>
        <location line="+775"/>
        <location line="+30"/>
        <source>Copy</source>
        <translation>Экземпляр</translation>
    </message>
    <message>
        <location line="-801"/>
        <location line="+772"/>
        <location line="+30"/>
        <location line="+1092"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="-803"/>
        <location line="+774"/>
        <location line="+30"/>
        <location line="+1088"/>
        <source>Move</source>
        <translation>Движение</translation>
    </message>
    <message>
        <location line="-1892"/>
        <location line="+771"/>
        <location line="+27"/>
        <location line="+1119"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="-1890"/>
        <location line="+773"/>
        <location line="+27"/>
        <location line="+1115"/>
        <source>Delete</source>
        <translation>Удаление</translation>
    </message>
    <message>
        <location line="-1888"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="-1886"/>
        <source>First time loading</source>
        <translation>Нагрузка первого раза</translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+1"/>
        <source>Thank you for download FilesPlus.
This is first time running, FolderPie needs to load information from your drive.

It will take time depends on numbers of sub folders/files under current folder.

Please click OK to continue.</source>
        <translation>Вы для загрузки FilesPlus.
Этому ход первого раза, FolderPie нужно нагрузить информацию от вашего привода.

Оно примет номера быть в зависимости от времени скоросшивателей/архивов под настоящий скоросшиватель.

Пожалуйста щелкните да для того чтобы продолжать.</translation>
    </message>
    <message>
        <location line="+16"/>
        <location line="+735"/>
        <location line="+20"/>
        <location line="+117"/>
        <location line="+97"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+16"/>
        <location line="+737"/>
        <location line="+20"/>
        <location line="+117"/>
        <location line="+96"/>
        <source>to</source>
        <translation>к</translation>
    </message>
    <message>
        <location line="-949"/>
        <location line="+50"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="-950"/>
        <location line="+50"/>
        <source>error</source>
        <translation>ошибка</translation>
    </message>
    <message>
        <location line="-45"/>
        <location line="+50"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="-45"/>
        <location line="+50"/>
        <source>failed</source>
        <translation>неудачно</translation>
    </message>
    <message>
        <location line="-25"/>
        <location line="+774"/>
        <location line="+349"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="-25"/>
        <location line="+776"/>
        <location line="+345"/>
        <source>Deleting</source>
        <translation>Удалять</translation>
    </message>
    <message>
        <location line="-1112"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="-1110"/>
        <source>is deleted.</source>
        <translation></translation>
    </message>
    <message>
        <location line="+414"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+410"/>
        <source>last modified</source>
        <translation>время даты</translation>
    </message>
    <message>
        <location line="+241"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+247"/>
        <source>Multiple actions</source>
        <translation>Множественные действия</translation>
    </message>
    <message>
        <location line="+10"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+10"/>
        <source>Invalid action</source>
        <translation>Инвалидное действие</translation>
    </message>
    <message>
        <location line="+144"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+144"/>
        <source>I can&apos;t </source>
        <translation>Я не могу</translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+1"/>
        <source>file</source>
        <translation>архив</translation>
    </message>
    <message>
        <location line="+48"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+48"/>
        <source>New Folder</source>
        <translation>Новый скоросшиватель</translation>
    </message>
    <message>
        <location line="+2"/>
        <location line="+39"/>
        <location line="+48"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+2"/>
        <location line="+39"/>
        <location line="+46"/>
        <source>OK</source>
        <translation>Да</translation>
    </message>
    <message>
        <location line="-87"/>
        <location line="+39"/>
        <location line="+48"/>
        <location line="+71"/>
        <location line="+33"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="-85"/>
        <location line="+39"/>
        <location line="+46"/>
        <location line="+69"/>
        <location line="+33"/>
        <source>Cancel</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location line="-181"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="-177"/>
        <source>Please input folder name.</source>
        <translation>Пожалуйста имя скоросшивателя входного сигнала.</translation>
    </message>
    <message>
        <location line="+27"/>
        <location line="+11"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+27"/>
        <location line="+10"/>
        <source>Rename</source>
        <translation>Переименуйте</translation>
    </message>
    <message>
        <location line="+9"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+8"/>
        <source>Please input new name.</source>
        <translation>Пожалуйста имя входного сигнала новое.</translation>
    </message>
    <message>
        <location line="+28"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+28"/>
        <source>File overwrite</source>
        <translation>Архив переписывает</translation>
    </message>
    <message>
        <location line="+10"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+9"/>
        <source>Please input new file name.</source>
        <translation>Пожалуйста имя файла входного сигнала.</translation>
    </message>
    <message>
        <location line="+14"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+13"/>
        <source>Overwrite existing file</source>
        <translation>Переписывайте существующий архивs</translation>
    </message>
    <message>
        <location line="+47"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+47"/>
        <source>Cancel sync jobs</source>
        <translation>Отмените работы синхронизации</translation>
    </message>
    <message>
        <location line="+2"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+2"/>
        <source>jobs</source>
        <translation>работы</translation>
    </message>
    <message>
        <location line="+10"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+10"/>
        <source>Cancel file action jobs</source>
        <translation>Отмените работы действия архива</translation>
    </message>
    <message>
        <location line="+16"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+16"/>
        <source>Rollback changes</source>
        <translation>Изменения отката назад</translation>
    </message>
    <message>
        <location line="+7"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+7"/>
        <source>jobs and abort file action ?</source>
        <translation>работы и действие архива прекращени прекращения ?</translation>
    </message>
    <message>
        <location line="+2"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+2"/>
        <source>Abort file action ?</source>
        <translation>Действие архива прекращени прекращения ?</translation>
    </message>
    <message>
        <location line="+20"/>
        <location line="+139"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+20"/>
        <location line="+139"/>
        <source>Printing</source>
        <translation>Печатать</translation>
    </message>
    <message>
        <location line="-41"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="-41"/>
        <source>Reset CloudPrint</source>
        <translation>Переустановите CloudPrint</translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+1"/>
        <source>Resetting is done.</source>
        <translation>Переустановить сделан.</translation>
    </message>
    <message>
        <location line="+34"/>
        <location line="+144"/>
        <location line="+37"/>
        <location line="+25"/>
        <location line="+47"/>
        <location line="+36"/>
        <location line="+113"/>
        <location line="+37"/>
        <location line="+141"/>
        <location line="+25"/>
        <location line="+45"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+34"/>
        <location line="+144"/>
        <location line="+37"/>
        <location line="+25"/>
        <location line="+47"/>
        <location line="+36"/>
        <location line="+113"/>
        <location line="+37"/>
        <location line="+141"/>
        <location line="+25"/>
        <location line="+45"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location line="-507"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="-507"/>
        <source>CloudDrive Request Token</source>
        <translation>Знак внимания запроса CloudDrive</translation>
    </message>
    <message>
        <location line="+28"/>
        <location line="+9"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+28"/>
        <location line="+9"/>
        <source>CloudDrive Access Token</source>
        <translation>Знак внимания доступа CloudDrive</translation>
    </message>
    <message>
        <location line="-8"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="-8"/>
        <source>Cloud drive user is authorized.
Please proceed your sync action.</source>
        <translation>Пользователь CloudDrive утвержен.
Пожалуйста продолжает ваше действие синхронизации.</translation>
    </message>
    <message>
        <location line="+33"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+33"/>
        <source>CloudDrive Account Info</source>
        <translation>Данные по учета CloudDrive</translation>
    </message>
    <message>
        <location line="+47"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+47"/>
        <source>File Get</source>
        <translation>Архив загрузки</translation>
    </message>
    <message>
        <location line="+36"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+36"/>
        <source>File Put</source>
        <translation>Архив Upload</translation>
    </message>
    <message>
        <location line="+46"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+46"/>
        <source>File</source>
        <translation>Aрхив</translation>
    </message>
    <message>
        <location line="+0"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+0"/>
        <source>was removed remotely.
Link will be removed.</source>
        <translation>извлекался отдаленно.
Соединение извлекается.</translation>
    </message>
    <message>
        <location line="+104"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+104"/>
        <source>Create Folder</source>
        <translation>Создайте скоросшиватель</translation>
    </message>
    <message>
        <location line="+202"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+202"/>
        <source>Share file on Dropbox</source>
        <translation>Архив доли на Dropbox</translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+1"/>
        <source>Please download file with below link.</source>
        <translation>Пожалуйста загрузите архив с внизу соединением.</translation>
    </message>
    <message>
        <location line="+8"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="+8"/>
        <source>Share</source>
        <translation>Доля</translation>
    </message>
</context>
<context>
    <name>FolderPieInfo</name>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPieInfo.qml" line="+42"/>
        <location filename="../qml/FilesPlus/symbian/FolderPieInfo.qml" line="+42"/>
        <source>FolderPie helps you collect each folder actual size on your disk space.
And present in Pie view for easy understanding at glance.</source>
        <translation>Помощь FolderPie вы собираете каждый действительный размер скоросшивателя на вашем космосе диска.
И представьте в взгляде расстегая для легкого вникания на блестняне.</translation>
    </message>
    <message>
        <location line="+11"/>
        <location filename="../qml/FilesPlus/symbian/FolderPieInfo.qml" line="+11"/>
        <source>Developed by</source>
        <translation>Превращено мимо</translation>
    </message>
</context>
<context>
    <name>FolderSizeItemListModel</name>
    <message>
        <location filename="../foldersizeitemlistmodel.cpp" line="+460"/>
        <location line="+22"/>
        <source>Source and Target path can&apos;t be the same.</source>
        <translation>Путь источника и цели не может быть этим же.</translation>
    </message>
    <message>
        <location line="-19"/>
        <location line="+22"/>
        <source>Target path can&apos;t be inside source path.</source>
        <translation>Путь цели не может быть внутренним путем источника.</translation>
    </message>
    <message>
        <location line="-17"/>
        <location line="+22"/>
        <source>Show running on targetPath&apos;s parent</source>
        <translation>Покажите ход на родителе путя цели</translation>
    </message>
    <message>
        <location line="+49"/>
        <source>Rename %1 to %2 done.</source>
        <translation>Переименуйте сделанные %1 к %2.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Rename %1 to %2 failed.</source>
        <translation>Переименуйте ые %1 к %2.</translation>
    </message>
    <message>
        <location line="+79"/>
        <source>Copy</source>
        <translation>Copy</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>_Copy</source>
        <translation>_Copy</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>_Copy%1</source>
        <translation>_Copy%1</translation>
    </message>
</context>
<context>
    <name>FolderSizeModelThread</name>
    <message>
        <location filename="../foldersizemodelthread.cpp" line="+146"/>
        <location line="+77"/>
        <location line="+64"/>
        <source>Copy %1 to %2 is aborted.</source>
        <translation>Экземпляр %1 до %2 выкинут.</translation>
    </message>
    <message>
        <location line="-91"/>
        <location line="+97"/>
        <source>Copy %1 to %2 is done successfully.</source>
        <translation>Экземпляр %1 до %2 сделан успешно.</translation>
    </message>
    <message>
        <location line="-94"/>
        <location line="+96"/>
        <source>Copy %1 to %2 is failed.</source>
        <translation>Экземпляр %1 до %2 неудачен.</translation>
    </message>
    <message>
        <location line="-51"/>
        <source>Both source/target path can&apos;t be the same file.</source>
        <translation>Оба путь источника/цели не может быть таким же архивом.</translation>
    </message>
    <message>
        <location line="+33"/>
        <source>Both source %1 and target %2 can&apos;t be read/written.</source>
        <translation>И источник %1 и цель %2 нельзя прочитать/написать.</translation>
    </message>
    <message>
        <location line="+73"/>
        <source>Deleting sub item %1 is failed.</source>
        <translation>Удалять деталь %1 неудачен.</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Deleting sub item %1 is done.</source>
        <translation>Удалять деталь %1 сделан.</translation>
    </message>
    <message>
        <location line="+420"/>
        <source>Deleting %1 is aborted.</source>
        <translation>Удалять %1 выкинут.</translation>
    </message>
</context>
<context>
    <name>MainMenu</name>
    <message>
        <location filename="../qml/FilesPlus/meego/MainMenu.qml" line="+19"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="+20"/>
        <source>Paste</source>
        <translation>Затир</translation>
    </message>
    <message>
        <location line="+8"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="+8"/>
        <source>Mark multiple items</source>
        <translation>Маркируйте множественные детали</translation>
    </message>
    <message>
        <location line="+8"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="+8"/>
        <source>Clear clipboard</source>
        <translation>Ясная доска сзажимом для бумаги</translation>
    </message>
    <message>
        <location line="+8"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="+8"/>
        <source>New folder</source>
        <translation>Новый скоросшиватель</translation>
    </message>
    <message>
        <location line="+8"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="+8"/>
        <source>Sync connected items</source>
        <translation>Детали соединенные синхронизацией</translation>
    </message>
    <message>
        <location line="+8"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="+8"/>
        <source>Sync current folder</source>
        <translation>Скоросшиватель течения синхронизации</translation>
    </message>
    <message>
        <location line="+9"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="+9"/>
        <source>Sort by</source>
        <translation>Вид мимо</translation>
    </message>
    <message>
        <location line="+8"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="+8"/>
        <source>Settings</source>
        <translation>Установки</translation>
    </message>
    <message>
        <location line="+14"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="+14"/>
        <source>About</source>
        <translation>О</translation>
    </message>
    <message>
        <location line="+14"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="+14"/>
        <source>Exit</source>
        <translation>Выход</translation>
    </message>
</context>
<context>
    <name>MarkAllMenu</name>
    <message>
        <location filename="../qml/FilesPlus/meego/MarkAllMenu.qml" line="+14"/>
        <source>Mark all</source>
        <translation>Маркируйте все</translation>
    </message>
</context>
<context>
    <name>MarkMenu</name>
    <message>
        <location filename="../qml/FilesPlus/meego/MarkMenu.qml" line="+18"/>
        <location filename="../qml/FilesPlus/symbian/MarkMenu.qml" line="+18"/>
        <source>Mark all</source>
        <translation>Маркируйте все</translation>
    </message>
    <message>
        <location line="+0"/>
        <location filename="../qml/FilesPlus/symbian/MarkMenu.qml" line="+0"/>
        <source>Unmark all</source>
        <translation>Извлекайте все метки</translation>
    </message>
    <message>
        <location line="+13"/>
        <location filename="../qml/FilesPlus/symbian/MarkMenu.qml" line="+13"/>
        <source>Copy marked items</source>
        <translation>Скопируйте маркированные детали</translation>
    </message>
    <message>
        <location line="+9"/>
        <location filename="../qml/FilesPlus/symbian/MarkMenu.qml" line="+9"/>
        <source>Cut marked items</source>
        <translation>Отрежьте маркированные детали</translation>
    </message>
    <message>
        <location line="+9"/>
        <location filename="../qml/FilesPlus/symbian/MarkMenu.qml" line="+9"/>
        <source>Delete marked items</source>
        <translation>Детали удаления маркированные</translation>
    </message>
    <message>
        <location line="+9"/>
        <location filename="../qml/FilesPlus/symbian/MarkMenu.qml" line="+9"/>
        <source>Sync marked items</source>
        <translation>Детали синхронизации маркированные</translation>
    </message>
</context>
<context>
    <name>MessageDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/MessageDialog.qml" line="+13"/>
        <location filename="../qml/FilesPlus/symbian/MessageDialog.qml" line="+13"/>
        <source>OK</source>
        <translation>Да</translation>
    </message>
</context>
<context>
    <name>PrintJobsPage</name>
    <message>
        <location filename="../qml/FilesPlus/meego/PrintJobsPage.qml" line="+43"/>
        <location filename="../qml/FilesPlus/symbian/PrintJobsPage.qml" line="+46"/>
        <source>Delete print jobs</source>
        <translation>Печатные работы удаления</translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="../qml/FilesPlus/symbian/PrintJobsPage.qml" line="+1"/>
        <source>Delete all print jobs ?</source>
        <translation>Удальте все печатные работы ?</translation>
    </message>
    <message>
        <location line="+59"/>
        <location line="+9"/>
        <location line="+26"/>
        <location filename="../qml/FilesPlus/symbian/PrintJobsPage.qml" line="+59"/>
        <location line="+9"/>
        <location line="+26"/>
        <source>Deleting</source>
        <translation>Удалять</translation>
    </message>
    <message>
        <location line="-19"/>
        <location filename="../qml/FilesPlus/symbian/PrintJobsPage.qml" line="-19"/>
        <source>Print Jobs</source>
        <translation>Печатные работы</translation>
    </message>
</context>
<context>
    <name>PrinterSelectionDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/PrinterSelectionDialog.qml" line="+11"/>
        <location filename="../qml/FilesPlus/symbian/PrinterSelectionDialog.qml" line="+10"/>
        <source>Print</source>
        <translation>Печать</translation>
    </message>
    <message>
        <location line="+0"/>
        <location filename="../qml/FilesPlus/symbian/PrinterSelectionDialog.qml" line="+0"/>
        <source>to</source>
        <translation>к</translation>
    </message>
    <message>
        <location line="+17"/>
        <location filename="../qml/FilesPlus/symbian/PrinterSelectionDialog.qml" line="+17"/>
        <source>Printing</source>
        <translation>Печатать</translation>
    </message>
</context>
<context>
    <name>ProgressDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/ProgressDialog.qml" line="+55"/>
        <location filename="../qml/FilesPlus/symbian/ProgressDialog.qml" line="+58"/>
        <source>Progressing</source>
        <translation>Развивать</translation>
    </message>
    <message>
        <location line="+2"/>
        <location filename="../qml/FilesPlus/symbian/ProgressDialog.qml" line="+2"/>
        <source>OK</source>
        <translation>Да</translation>
    </message>
    <message>
        <location line="+0"/>
        <location filename="../qml/FilesPlus/symbian/ProgressDialog.qml" line="+0"/>
        <source>Cancel</source>
        <translation>Нет</translation>
    </message>
</context>
<context>
    <name>RecipientSelectionDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/RecipientSelectionDialog.qml" line="+18"/>
        <location filename="../qml/FilesPlus/symbian/RecipientSelectionDialog.qml" line="+17"/>
        <source>Send</source>
        <translation>Пошлите</translation>
    </message>
    <message>
        <location line="+0"/>
        <location filename="../qml/FilesPlus/symbian/RecipientSelectionDialog.qml" line="+0"/>
        <source>to favorite</source>
        <translation>к фавориту</translation>
    </message>
</context>
<context>
    <name>SettingMenu</name>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingMenu.qml" line="+22"/>
        <location filename="../qml/FilesPlus/symbian/SettingMenu.qml" line="+17"/>
        <source>Show CloudPrint jobs</source>
        <translation>Покажите работы CloudPrint</translation>
    </message>
    <message>
        <location line="+8"/>
        <location filename="../qml/FilesPlus/symbian/SettingMenu.qml" line="+8"/>
        <source>Reset CloudPrint</source>
        <translation>Переустановите CloudPrint</translation>
    </message>
    <message>
        <location line="+7"/>
        <location filename="../qml/FilesPlus/symbian/SettingMenu.qml" line="+7"/>
        <source>Register new Dropbox account</source>
        <translation>Учет Dropbox регистра новый</translation>
    </message>
    <message>
        <location line="+8"/>
        <location filename="../qml/FilesPlus/symbian/SettingMenu.qml" line="+8"/>
        <source>Reset current folder cache</source>
        <translation>Переустановите настоящий тайник скоросшивателя</translation>
    </message>
</context>
<context>
    <name>SettingPage</name>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="+24"/>
        <location line="+126"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="+24"/>
        <location line="+126"/>
        <source>Cancel queued jobs</source>
        <translation>Отмените работы очереди</translation>
    </message>
    <message>
        <location line="-119"/>
        <location line="+120"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="-119"/>
        <location line="+120"/>
        <source>Sync all connected items</source>
        <translation>Синхронизация все соединенные детали</translation>
    </message>
    <message>
        <location line="-98"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="-98"/>
        <source>Settings</source>
        <translation>Установки</translation>
    </message>
    <message>
        <location line="+6"/>
        <location line="+96"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="+6"/>
        <location line="+96"/>
        <source>Logging (Debug)</source>
        <translation>Вносить в журнал (отлаживайте)</translation>
    </message>
    <message>
        <location line="-95"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="-95"/>
        <source>Changing logging switch requires restart.
FilesPlus is exiting now.

Please confirm.</source>
        <translation>Изменяя внося в журнал переключатель требует рестарта.
FilesPlus выходит теперь.

Пожалуйста подтвердите.</translation>
    </message>
    <message>
        <location line="+87"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="+87"/>
        <source>Show cloud print jobs</source>
        <translation>Покажите работы CloudPrint</translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="+1"/>
        <source>Reset cloud print</source>
        <translation>Переустановите CloudPrint</translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="+1"/>
        <source>Show cloud drive jobs</source>
        <translation>Покажите работы CloudDrive</translation>
    </message>
    <message>
        <location line="+3"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="+3"/>
        <source>Show accounts</source>
        <translation>Покажите учет CloudDrive</translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="+1"/>
        <source>FolderPie feature</source>
        <translation>Характеристика FolderPie</translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="+1"/>
        <source>Reset current folder cache</source>
        <translation>Переустановите настоящий тайник скоросшивателя</translation>
    </message>
    <message>
        <location line="+2"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="+2"/>
        <source>Monitoring (RAM,CPU)</source>
        <translation>Контролирующ (RAM, C.P.U.)</translation>
    </message>
    <message>
        <location line="+26"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="+26"/>
        <source>Monitoring</source>
        <translation>Контролировать</translation>
    </message>
    <message>
        <location line="+1"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="+1"/>
        <source>Monitoring is enabled. Log file is </source>
        <translation>Контроль позволен. Архив журнала </translation>
    </message>
</context>
<context>
    <name>SortByMenu</name>
    <message>
        <location filename="../qml/FilesPlus/meego/SortByMenu.qml" line="+21"/>
        <location filename="../qml/FilesPlus/symbian/SortByMenu.qml" line="+17"/>
        <source>Sort by Name</source>
        <translation>Вид именем</translation>
    </message>
    <message>
        <location line="+10"/>
        <location filename="../qml/FilesPlus/symbian/SortByMenu.qml" line="+9"/>
        <source>Sort by Type</source>
        <translation>Вид типом</translation>
    </message>
    <message>
        <location line="+10"/>
        <location filename="../qml/FilesPlus/symbian/SortByMenu.qml" line="+9"/>
        <source>Sort by Time</source>
        <translation>Вид к время</translation>
    </message>
    <message>
        <location line="+10"/>
        <location filename="../qml/FilesPlus/symbian/SortByMenu.qml" line="+9"/>
        <source>Sort by Size</source>
        <translation>Вид размером</translation>
    </message>
</context>
<context>
    <name>ToolMenu</name>
    <message>
        <location filename="../qml/FilesPlus/meego/ToolMenu.qml" line="+15"/>
        <location filename="../qml/FilesPlus/symbian/ToolMenu.qml" line="+15"/>
        <source>Mark</source>
        <translation>Марк</translation>
    </message>
    <message>
        <location line="+8"/>
        <location filename="../qml/FilesPlus/symbian/ToolMenu.qml" line="+8"/>
        <source>New Folder</source>
        <translation>Новый скоросшиватель</translation>
    </message>
    <message>
        <location line="+8"/>
        <location filename="../qml/FilesPlus/symbian/ToolMenu.qml" line="+8"/>
        <source>Rename</source>
        <translation>Переименуйте</translation>
    </message>
</context>
<context>
    <name>UploadProgressDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/UploadProgressDialog.qml" line="+16"/>
        <location filename="../qml/FilesPlus/symbian/UploadProgressDialog.qml" line="+16"/>
        <source>Uploading</source>
        <translation>Загружать</translation>
    </message>
    <message>
        <location line="+2"/>
        <location filename="../qml/FilesPlus/symbian/UploadProgressDialog.qml" line="+2"/>
        <source>OK</source>
        <translation>Да</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../qml/FilesPlus/meego/main.qml" line="+91"/>
        <location filename="../qml/FilesPlus/symbian/main.qml" line="+102"/>
        <source>Please wait while loading.</source>
        <translation>Пожалуйста ждите пока нагружающ.</translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/symbian/main.qml" line="-50"/>
        <source>Notify</source>
        <translation>Сообщите</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Logging is enabled. Log file is at </source>
        <translation>Вносить в журнал позволен. Архив журнала на</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>You may turn off in Settings.</source>
        <translation>Вы можете повернуть в установки.</translation>
    </message>
</context>
</TS>
