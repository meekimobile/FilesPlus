<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de">
<context>
    <name>AuthPage</name>
    <message>
        <location filename="../qml/FilesPlus/meego/AuthPage.qml" line="127"/>
        <location filename="../qml/FilesPlus/symbian/AuthPage.qml" line="128"/>
        <source>^API Request Authorized</source>
        <translation>^API Antrag Autorisiert</translation>
    </message>
</context>
<context>
    <name>CloudDriveAccountsPage</name>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveAccountsPage.qml" line="75"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveAccountsPage.qml" line="78"/>
        <source>Cloud Drive Accounts</source>
        <translation>Cloud Drive Accounts</translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveAccountsPage.qml" line="113"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveAccountsPage.qml" line="116"/>
        <source>Remove cloud drive account</source>
        <translation>Löschen Sie Cloud Drive Account</translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveAccountsPage.qml" line="119"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveAccountsPage.qml" line="122"/>
        <source>Please confirm to remove </source>
        <translation>Bestätigen Sie bitte, um zu löschen</translation>
    </message>
</context>
<context>
    <name>CloudDriveJobsPage</name>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveJobsPage.qml" line="79"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveJobsPage.qml" line="82"/>
        <source>Cloud Drive Jobs</source>
        <translation type="unfinished">Cloud Drive Jobs</translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveJobsPage.qml" line="159"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveJobsPage.qml" line="161"/>
        <source>Running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveJobsPage.qml" line="159"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveJobsPage.qml" line="161"/>
        <source>Queued</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CloudDriveUsersDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveUsersDialog.qml" line="26"/>
        <location filename="../qml/FilesPlus/meego/CloudDriveUsersDialog.qml" line="34"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="26"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="34"/>
        <source>Sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveUsersDialog.qml" line="26"/>
        <location filename="../qml/FilesPlus/meego/CloudDriveUsersDialog.qml" line="34"/>
        <location filename="../qml/FilesPlus/meego/CloudDriveUsersDialog.qml" line="38"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="26"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="34"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="38"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveUsersDialog.qml" line="34"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="34"/>
        <source>items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveUsersDialog.qml" line="34"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="34"/>
        <source>item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveUsersDialog.qml" line="38"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="38"/>
        <source>Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveUsersDialog.qml" line="41"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="41"/>
        <source>Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveUsersDialog.qml" line="41"/>
        <location filename="../qml/FilesPlus/meego/CloudDriveUsersDialog.qml" line="44"/>
        <location filename="../qml/FilesPlus/meego/CloudDriveUsersDialog.qml" line="47"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="41"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="44"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="47"/>
        <source>from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveUsersDialog.qml" line="44"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="44"/>
        <source>Share link of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/CloudDriveUsersDialog.qml" line="47"/>
        <location filename="../qml/FilesPlus/symbian/CloudDriveUsersDialog.qml" line="47"/>
        <source>Unsync</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CommonDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/CommonDialog.qml" line="16"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/CommonDialog.qml" line="16"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfirmDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/ConfirmDialog.qml" line="8"/>
        <location filename="../qml/FilesPlus/symbian/ConfirmDialog.qml" line="11"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/ConfirmDialog.qml" line="8"/>
        <location filename="../qml/FilesPlus/symbian/ConfirmDialog.qml" line="11"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadProgressDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/DownloadProgressDialog.qml" line="16"/>
        <location filename="../qml/FilesPlus/symbian/DownloadProgressDialog.qml" line="16"/>
        <source>Downloading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/DownloadProgressDialog.qml" line="18"/>
        <location filename="../qml/FilesPlus/symbian/DownloadProgressDialog.qml" line="18"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DriveGrid</name>
    <message>
        <location filename="../qml/FilesPlus/meego/DriveGrid.qml" line="146"/>
        <location filename="../qml/FilesPlus/symbian/DriveGrid.qml" line="146"/>
        <source>Free</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/DriveGrid.qml" line="147"/>
        <location filename="../qml/FilesPlus/symbian/DriveGrid.qml" line="147"/>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DrivePage</name>
    <message>
        <location filename="../qml/FilesPlus/meego/DrivePage.qml" line="101"/>
        <location filename="../qml/FilesPlus/symbian/DrivePage.qml" line="105"/>
        <source>Drives</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/symbian/DrivePage.qml" line="44"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/symbian/DrivePage.qml" line="44"/>
        <source>More Apps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/symbian/DrivePage.qml" line="44"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/symbian/DrivePage.qml" line="44"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FilesPlusInfo</name>
    <message>
        <location filename="../qml/FilesPlus/meego/FilesPlusInfo.qml" line="41"/>
        <location filename="../qml/FilesPlus/symbian/FilesPlusInfo.qml" line="41"/>
        <source>FilesPlus provides extended functions beyond file manager.
   + Print with Google Cloud Print.
   + Sync with Cloud Drive.
   + Preview images in your folder.
   + Present folders in Pie view.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FilesPlusInfo.qml" line="82"/>
        <location filename="../qml/FilesPlus/symbian/FilesPlusInfo.qml" line="82"/>
        <source>Developed by </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FolderPage</name>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="23"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="23"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="23"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="23"/>
        <source>Mark multiple items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="23"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="23"/>
        <source>Clear clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="23"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="23"/>
        <source>New folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="23"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="23"/>
        <source>Sync current folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="23"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="23"/>
        <source>Sort by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="178"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="158"/>
        <source>Reset folder cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="179"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="159"/>
        <source>Resetting folder cache will take time depends on numbers of sub folders/files under current folder.

Please click OK to continue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="214"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="194"/>
        <source>Notify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="215"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="195"/>
        <source>Reset Cache is running. Please wait until it&apos;s done.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="232"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="212"/>
        <source>Print Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="233"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="213"/>
        <source>Can&apos;t print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="234"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="214"/>
        <source>File type is not supported. Only JPEG, PNG, Text and PDF are supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="240"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="220"/>
        <source>FilesPlus print via Google CloudPrint service.
Please enable printer on your desktop with Chrome or with CloudPrint-ready printer.
You will redirect to authorization page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="243"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="223"/>
        <source>Print with CloudPrint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="256"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="236"/>
        <source>Search for printers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="288"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="268"/>
        <source>FilesPlus syncs your files via Dropbox service.
You will be redirected to authorization page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="290"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="270"/>
        <source>Sync with Dropbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="397"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1170"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1200"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="377"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1152"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1182"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="399"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1171"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1201"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="2293"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="379"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1153"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1183"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="2271"/>
        <source>Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="401"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1172"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1199"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="2318"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="381"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1154"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1181"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="2296"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="430"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="410"/>
        <source>First time loading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="431"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="411"/>
        <source>Thank you for download FilesPlus.
This is first time running, FolderPie needs to load information from your drive.

It will take time depends on numbers of sub folders/files under current folder.

Please click OK to continue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="447"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1182"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1202"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1319"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1416"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="427"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1164"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1184"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1301"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1397"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="467"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="517"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="447"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="497"/>
        <source>error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="472"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="522"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="452"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="502"/>
        <source>failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="497"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1271"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1620"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="477"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1253"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1598"/>
        <source>Deleting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="508"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="488"/>
        <source>is deleted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="922"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="898"/>
        <source>last modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1163"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1145"/>
        <source>Multiple actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1173"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1155"/>
        <source>Invalid action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1317"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1299"/>
        <source>I can&apos;t </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1318"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1300"/>
        <source>file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1366"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1348"/>
        <source>New Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1368"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1407"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1455"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1350"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1389"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1435"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1368"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1407"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1455"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1526"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1559"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1350"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1389"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1435"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1504"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1537"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1378"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1360"/>
        <source>Please input folder name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1405"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1416"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1387"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1397"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1425"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1405"/>
        <source>Please input new name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1453"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1433"/>
        <source>File overwrite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1463"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1442"/>
        <source>Please input new file name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1477"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1455"/>
        <source>Overwrite existing file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1524"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1502"/>
        <source>Cancel sync jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1526"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1504"/>
        <source>jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1536"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1514"/>
        <source>Cancel file action jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1552"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1530"/>
        <source>Rollback changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1559"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1537"/>
        <source>jobs and abort file action ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1561"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1539"/>
        <source>Abort file action ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1581"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1720"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1559"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1698"/>
        <source>Printing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1679"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1657"/>
        <source>Reset CloudPrint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1680"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1658"/>
        <source>Resetting is done.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1714"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1858"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1895"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1920"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1967"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="2003"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="2116"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="2153"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="2294"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="2319"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="2364"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1692"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1836"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1873"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1898"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1945"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1981"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="2094"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="2131"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="2272"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="2297"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="2342"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1857"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1835"/>
        <source>CloudDrive Request Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1885"/>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1894"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1863"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1872"/>
        <source>CloudDrive Access Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1886"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1864"/>
        <source>Cloud drive user is authorized.
Please proceed your sync action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1919"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1897"/>
        <source>CloudDrive Account Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="1966"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1944"/>
        <source>File Get</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="2002"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="1980"/>
        <source>File Put</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="2048"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="2026"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="2048"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="2026"/>
        <source>was removed remotely.
Link will be removed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="2152"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="2130"/>
        <source>Create Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="2354"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="2332"/>
        <source>Share file on Dropbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="2355"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="2333"/>
        <source>Please download file with below link.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPage.qml" line="2363"/>
        <location filename="../qml/FilesPlus/symbian/FolderPage.qml" line="2341"/>
        <source>Share</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FolderPieInfo</name>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPieInfo.qml" line="42"/>
        <location filename="../qml/FilesPlus/symbian/FolderPieInfo.qml" line="42"/>
        <source>FolderPie helps you collect each folder actual size on your disk space.
And present in Pie view for easy understanding at glance.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/FolderPieInfo.qml" line="53"/>
        <location filename="../qml/FilesPlus/symbian/FolderPieInfo.qml" line="53"/>
        <source>Developed by</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FolderSizeItemListModel</name>
    <message>
        <location filename="../foldersizeitemlistmodel.cpp" line="460"/>
        <location filename="../foldersizeitemlistmodel.cpp" line="482"/>
        <source>Source and Target path can&apos;t be the same.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldersizeitemlistmodel.cpp" line="463"/>
        <location filename="../foldersizeitemlistmodel.cpp" line="485"/>
        <source>Target path can&apos;t be inside source path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldersizeitemlistmodel.cpp" line="468"/>
        <location filename="../foldersizeitemlistmodel.cpp" line="490"/>
        <source>Show running on targetPath&apos;s parent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldersizeitemlistmodel.cpp" line="539"/>
        <source>Rename %1 to %2 done.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldersizeitemlistmodel.cpp" line="542"/>
        <source>Rename %1 to %2 failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldersizeitemlistmodel.cpp" line="621"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldersizeitemlistmodel.cpp" line="629"/>
        <source>_Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldersizeitemlistmodel.cpp" line="631"/>
        <source>_Copy%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FolderSizeModelThread</name>
    <message>
        <location filename="../foldersizemodelthread.cpp" line="146"/>
        <location filename="../foldersizemodelthread.cpp" line="223"/>
        <location filename="../foldersizemodelthread.cpp" line="287"/>
        <source>Copy %1 to %2 is aborted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldersizemodelthread.cpp" line="196"/>
        <location filename="../foldersizemodelthread.cpp" line="293"/>
        <source>Copy %1 to %2 is done successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldersizemodelthread.cpp" line="199"/>
        <location filename="../foldersizemodelthread.cpp" line="295"/>
        <source>Copy %1 to %2 is failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldersizemodelthread.cpp" line="244"/>
        <source>Both source/target path can&apos;t be the same file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldersizemodelthread.cpp" line="277"/>
        <source>Both source %1 and target %2 can&apos;t be read/written.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldersizemodelthread.cpp" line="350"/>
        <source>Deleting sub item %1 is failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldersizemodelthread.cpp" line="354"/>
        <source>Deleting sub item %1 is done.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldersizemodelthread.cpp" line="774"/>
        <source>Deleting %1 is aborted.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainMenu</name>
    <message>
        <location filename="../qml/FilesPlus/meego/MainMenu.qml" line="19"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="20"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/MainMenu.qml" line="27"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="28"/>
        <source>Mark multiple items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/MainMenu.qml" line="35"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="36"/>
        <source>Clear clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/MainMenu.qml" line="43"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="44"/>
        <source>New folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/MainMenu.qml" line="51"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="52"/>
        <source>Sync connected items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/MainMenu.qml" line="59"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="60"/>
        <source>Sync current folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/MainMenu.qml" line="68"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="69"/>
        <source>Sort by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/MainMenu.qml" line="76"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="77"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/MainMenu.qml" line="90"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="91"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/MainMenu.qml" line="104"/>
        <location filename="../qml/FilesPlus/symbian/MainMenu.qml" line="105"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MarkAllMenu</name>
    <message>
        <location filename="../qml/FilesPlus/meego/MarkAllMenu.qml" line="14"/>
        <source>Mark all</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MarkMenu</name>
    <message>
        <location filename="../qml/FilesPlus/meego/MarkMenu.qml" line="18"/>
        <location filename="../qml/FilesPlus/symbian/MarkMenu.qml" line="18"/>
        <source>Mark all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/MarkMenu.qml" line="18"/>
        <location filename="../qml/FilesPlus/symbian/MarkMenu.qml" line="18"/>
        <source>Unmark all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/MarkMenu.qml" line="31"/>
        <location filename="../qml/FilesPlus/symbian/MarkMenu.qml" line="31"/>
        <source>Copy marked items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/MarkMenu.qml" line="40"/>
        <location filename="../qml/FilesPlus/symbian/MarkMenu.qml" line="40"/>
        <source>Cut marked items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/MarkMenu.qml" line="49"/>
        <location filename="../qml/FilesPlus/symbian/MarkMenu.qml" line="49"/>
        <source>Delete marked items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/MarkMenu.qml" line="58"/>
        <location filename="../qml/FilesPlus/symbian/MarkMenu.qml" line="58"/>
        <source>Sync marked items</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessageDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/MessageDialog.qml" line="13"/>
        <location filename="../qml/FilesPlus/symbian/MessageDialog.qml" line="13"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintJobsPage</name>
    <message>
        <location filename="../qml/FilesPlus/meego/PrintJobsPage.qml" line="43"/>
        <location filename="../qml/FilesPlus/symbian/PrintJobsPage.qml" line="46"/>
        <source>Delete print jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/PrintJobsPage.qml" line="44"/>
        <location filename="../qml/FilesPlus/symbian/PrintJobsPage.qml" line="47"/>
        <source>Delete all print jobs ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/PrintJobsPage.qml" line="103"/>
        <location filename="../qml/FilesPlus/meego/PrintJobsPage.qml" line="112"/>
        <location filename="../qml/FilesPlus/meego/PrintJobsPage.qml" line="138"/>
        <location filename="../qml/FilesPlus/symbian/PrintJobsPage.qml" line="106"/>
        <location filename="../qml/FilesPlus/symbian/PrintJobsPage.qml" line="115"/>
        <location filename="../qml/FilesPlus/symbian/PrintJobsPage.qml" line="141"/>
        <source>Deleting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/PrintJobsPage.qml" line="119"/>
        <location filename="../qml/FilesPlus/symbian/PrintJobsPage.qml" line="122"/>
        <source>Print Jobs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrinterSelectionDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/PrinterSelectionDialog.qml" line="11"/>
        <location filename="../qml/FilesPlus/symbian/PrinterSelectionDialog.qml" line="10"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/PrinterSelectionDialog.qml" line="11"/>
        <location filename="../qml/FilesPlus/symbian/PrinterSelectionDialog.qml" line="10"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/PrinterSelectionDialog.qml" line="28"/>
        <location filename="../qml/FilesPlus/symbian/PrinterSelectionDialog.qml" line="27"/>
        <source>Printing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProgressDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/ProgressDialog.qml" line="55"/>
        <location filename="../qml/FilesPlus/symbian/ProgressDialog.qml" line="58"/>
        <source>Progressing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/ProgressDialog.qml" line="57"/>
        <location filename="../qml/FilesPlus/symbian/ProgressDialog.qml" line="60"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/ProgressDialog.qml" line="57"/>
        <location filename="../qml/FilesPlus/symbian/ProgressDialog.qml" line="60"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RecipientSelectionDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/RecipientSelectionDialog.qml" line="18"/>
        <location filename="../qml/FilesPlus/symbian/RecipientSelectionDialog.qml" line="17"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/RecipientSelectionDialog.qml" line="18"/>
        <location filename="../qml/FilesPlus/symbian/RecipientSelectionDialog.qml" line="17"/>
        <source>to favorite</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingMenu</name>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingMenu.qml" line="22"/>
        <location filename="../qml/FilesPlus/symbian/SettingMenu.qml" line="17"/>
        <source>Show CloudPrint jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingMenu.qml" line="30"/>
        <location filename="../qml/FilesPlus/symbian/SettingMenu.qml" line="25"/>
        <source>Reset CloudPrint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingMenu.qml" line="37"/>
        <location filename="../qml/FilesPlus/symbian/SettingMenu.qml" line="32"/>
        <source>Register new Dropbox account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingMenu.qml" line="45"/>
        <location filename="../qml/FilesPlus/symbian/SettingMenu.qml" line="40"/>
        <source>Reset current folder cache</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingPage</name>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="24"/>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="150"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="24"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="150"/>
        <source>Cancel queued jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="31"/>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="151"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="31"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="151"/>
        <source>Sync all connected items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="53"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="53"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="59"/>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="155"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="59"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="155"/>
        <source>Logging (Debug)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="60"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="60"/>
        <source>Changing logging switch requires restart.
FilesPlus is exiting now.

Please confirm.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="147"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="147"/>
        <source>Show cloud print jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="148"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="148"/>
        <source>Reset cloud print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="149"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="149"/>
        <source>Show cloud drive jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="152"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="152"/>
        <source>Show accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="153"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="153"/>
        <source>FolderPie feature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="154"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="154"/>
        <source>Reset current folder cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="156"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="156"/>
        <source>Monitoring (RAM,CPU)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="182"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="182"/>
        <source>Monitoring</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SettingPage.qml" line="183"/>
        <location filename="../qml/FilesPlus/symbian/SettingPage.qml" line="183"/>
        <source>Monitoring is enabled. Log file is </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SortByMenu</name>
    <message>
        <location filename="../qml/FilesPlus/meego/SortByMenu.qml" line="21"/>
        <location filename="../qml/FilesPlus/symbian/SortByMenu.qml" line="17"/>
        <source>Sort by Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SortByMenu.qml" line="31"/>
        <location filename="../qml/FilesPlus/symbian/SortByMenu.qml" line="26"/>
        <source>Sort by Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SortByMenu.qml" line="41"/>
        <location filename="../qml/FilesPlus/symbian/SortByMenu.qml" line="35"/>
        <source>Sort by Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/SortByMenu.qml" line="51"/>
        <location filename="../qml/FilesPlus/symbian/SortByMenu.qml" line="44"/>
        <source>Sort by Size</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolMenu</name>
    <message>
        <location filename="../qml/FilesPlus/meego/ToolMenu.qml" line="15"/>
        <location filename="../qml/FilesPlus/symbian/ToolMenu.qml" line="15"/>
        <source>Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/ToolMenu.qml" line="23"/>
        <location filename="../qml/FilesPlus/symbian/ToolMenu.qml" line="23"/>
        <source>New Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/ToolMenu.qml" line="31"/>
        <location filename="../qml/FilesPlus/symbian/ToolMenu.qml" line="31"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UploadProgressDialog</name>
    <message>
        <location filename="../qml/FilesPlus/meego/UploadProgressDialog.qml" line="16"/>
        <location filename="../qml/FilesPlus/symbian/UploadProgressDialog.qml" line="16"/>
        <source>Uploading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/meego/UploadProgressDialog.qml" line="18"/>
        <location filename="../qml/FilesPlus/symbian/UploadProgressDialog.qml" line="18"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../qml/FilesPlus/meego/main.qml" line="91"/>
        <location filename="../qml/FilesPlus/symbian/main.qml" line="102"/>
        <source>Please wait while loading.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/symbian/main.qml" line="52"/>
        <source>Notify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/symbian/main.qml" line="53"/>
        <source>Logging is enabled. Log file is at </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/FilesPlus/symbian/main.qml" line="53"/>
        <source>You may turn off in Settings.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
